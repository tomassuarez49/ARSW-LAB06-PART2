

//========//
//Datos de prueba usados para probar la interfaz mientras no haya
//conexión con el servidor
var p1 = new Plato("papas", 1000);
var p2 = new Plato("gaseosa", 500);

var o = new Orden();
o.agregarPlato(p1);
var o2 = new Orden();
o2.agregarPlato(p2);
//========//

//la orden actualmente seleccionada
ordenActual = new Orden();

//identificador de la orden actualente seleccionada
idOrdenActual=-1;

//ordenes actualmente disponibles
ordenesDisponibles = []

//platos actualmente disponibles
platos=[];

/**
 * Actualiza el conjunto de ordenes disponibles mostradas, consultando las mismas
 * en el servidor. La actualización se realiza de manera asíncrona con AJAX.
 * 
 */
actualizarOrdenesDisponibles = function () {
    //datos de prueba
    ordenesDisponibles = [o, o2];
    
    //actualizar presentación
};

/**
 * Agrega un nuevo plato a la orden actual, la actualiza en el servidor, y 
 * recalcula el precio.
 * Se debe tener en cuenta que el precio NO se podrá calcular hasta que
 * se haya hecho la actualización (para esto use 'promesas' encadenadas).
 * es dado por el servidor).
 * @param {type} p
 * @returns {undefined}
 */
agregarPlatoOrdenActual = function (p) {
    ordenActual.agregarPlato(p);
    //actualizar orden en el servidor
    
    //recalcular precio
                
    //mostrar precio actualizado. Por ahora se muestra uno aleatorio
    $("#resumenCuenta").children().remove();
    $("#resumenCuenta").append("<h1>Total:<h1>"+(Math.random()*10000));
};

/**
 * Cambia la orden actualmente seleccionada
 * @param {type} id
 * @returns {undefined}
 */
cambiarOrdenActual = function (id) {
    idOrdenActual=id;
    ordenActual = ordenesDisponibles[id];

    //actualizar la presentación

};

/**
 * Actualiza el listado de los platos disponibles
 * @returns {undefined}
 */
actualizarPlatosDisponibles = function () {
    //datos de prueba
    var platosdisp = [p1,p2,p1,p1];
    
    //crer un mapa de objetos plato, donde la llave es su nombre
    for (i = 0; i < platosdisp.length; i++) {        
        platos[platosdisp[i].nombre]=platosdisp[i];
        
        //actualizar la vista, agregando el nuevo plato!
    }
    
    //definir los elementos de la lista como 'draggables'
};

/**
 * Operaciones que se realizarán automáticamente una vez el DOM haya sido
 * cargado por completo.
 * 
 */
$(document).ready(
        function () {
            
            actualizarPlatosDisponibles();            
            
           
            
        }
);

